Author: Gino Malpartida
This program performs statistical analytics on a dataset.  
It calculates the mean, median, maximum and minimum of an array of 40 numbers. 
